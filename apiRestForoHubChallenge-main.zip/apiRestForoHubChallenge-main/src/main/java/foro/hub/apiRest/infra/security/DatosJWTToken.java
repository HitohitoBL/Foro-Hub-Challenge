package foro.hub.apiRest.infra.security;

public record DatosJWTToken(String jwtToken) {
}
